# GitHub Codespaces — clean install

1. Create a new empty GitHub repository and open a new Codespace on `main`.
2. Upload `insider-one-notification-delivery.zip` to the repository root in Codespaces.
3. Run the following commands in the Codespaces terminal:

```bash
unzip insider-one-notification-delivery.zip
cd insider-one-notification
docker compose up --build -d
docker compose ps
docker compose exec app ./vendor/bin/phpunit
curl -i http://localhost:8000/api/health
```

Five services should start: `app`, `mysql`, `redis`, `worker`, `scheduler`.
The ZIP includes `.env` with the requested webhook.site URL. `.env` is intentionally Git-ignored. For a fresh **Git clone**, use `cp .env.example .env` before starting Docker.

To push source code from a Codespace created in the repo root:

```bash
cd ..
git add insider-one-notification
git status --short
git commit -m "Implement notification service"
git push origin main
```

Do not commit `.env`, log files or ZIP archives. For full API examples and design details see `README.md`.
